---
docgraph:
  id: c5.excess-two-n2-unary-three-row-escape
  family: [c5, c5.excess-two, c5.n2]
  requires:
    - c5.excess-two-n2-residual-unification
    - c5.excess-two-arc-size-bound
---
# N2 原55：unary 三列未用色出口與兩short排除候選

**後續涵蓋（2026-10-13）**：[三列出口採納](c5_excess_two_n2_diagonal_three_row.md)
已排本頁完整契約的 `(0,1)`；[LL-CUT+diag](c5_excess_two_n2_ll_cut.md)
合其餘原55子分支完成指定完整Σ契約九格覆蓋。
[N2-BRIDGE](c5_excess_two_n2_bridge.md#0-依賴與覆蓋的閱讀順序)另補932來源橋接，
排原E4完整三列來源契約的N2；基本LL-CUT未獨立證成，E-ARC2的N1／相鄰分支仍OPEN。
下文候選、未採納及OPEN敘述均保留當輪語境，原契約與證据不改。

**整理發布（2026-10-11）**：相連四輪成果由[發布紀錄](history/2026-10-11-n2-55-progress-publish.md)
統一保存驗證與提交範圍；下文原生成基準及當輪「未提交」語境保留。

2026-10-11；基準 HEAD `5f0979793c19e452dbb5fc7e9fe7e43cb8a991cc`。
接續 [N2 統一報告 §5](c5_excess_two_n2_residual_unification.md#5-剩餘四個參數情形的精確缺條件)。
本輪只推進 `(ℓ,u)=(0,1)` 的缺條件，沒有搜尋10–35內點。

**後續採納（2026-10-11）**：另人獨立紙面審查已通過無界 block-tree 覆蓋及
同列完整接回；完整 N2 的 `(ℓ,u)=(0,1)` 原55子族已排，與既有 u=2 排除合併
覆蓋第三 relation 族。精確裁決、低接點 long 化約與剩餘三情形見
[三列 diagonal 採納報告](c5_excess_two_n2_diagonal_three_row.md)。
下文保留原候選及当輪「未採納」語境；原55全族、N2、E-ARC2仍 OPEN。

**完整紙面候選 N2-55-U-THREE-ROW-ESCAPE：同一原 unary U 不可能在
q₀、q₁、q₃ 都禁止 owner 取未用色 D=3。** 若採納，兩份原short可在
該同一列、同一(D,D)接回，排除 `(ℓ,u)=(0,1)` 原55子族。
作者已核對無界分支／量詞並完成局部checker；**未作另人獨立纸面採納**。
已採納的四情形表保留，新候選另列；原55全族、完整N2、E-ARC2仍 **OPEN**。
沒有新Lean theorem，沒有commit／push。

## 1. 完整契約與局部前提

來源推論沿用 [spoke §1](c5_excess_two_arc_spoke_closure.md#1-完整來源前提與依賴)
及 [統一報告 §1](c5_excess_two_n2_residual_unification.md#1-九格對應與完整契約)
全部契約：同一有限簡單 induced-C₅ disk、指定有序B、完整Σ933／941或整圖共同D₅像、
T4全收、全部非框邊Σ-critical、ε=2、有效H連通且full B-touch、非相鄰原degree5
roots r,s，其餘有效內點原完整degree4、恰兩份原mixed P,Q。
保留全部原 contacts／shared contacts、ownership、attachments、rotation、bridges、旁支、
字面色框及完整relations／空fibres／full lifts。共同搬運整圖後固定

\[
q_0=01212,\quad q_1=01202,\quad q_3=01021,\qquad D=3.
\]

u=1時，U的owner記為r，k=|N_U(r)|。既有末端引理給k≥2；兩mixed各至少一條
r-contact，原degree5給 **k∈{2,3}**。k=3另迫tᵣ=0、k_P^r=k_Q^r=1。
局部候選只使用以下已由完整來源推出的事實：

| 局部前提 | 既有來源 |
| --- | --- |
| U連通、只接r、每點原完整degree4、k=2或3；blocks是bridges／奇環 | [末端引理](c5_excess_two_arc_spoke_closure.md#3-末端-block-必有私有-root-接點原-unit-unary-不存在)、[大小界 §4](c5_excess_two_arc_size_bound.md#4-原c不含k₄cactus的初等計數) |
| 每點框附件至多相鄰兩點；U支援至少三個框點 | [全刪邊釋放](c5_excess_two_arc_spoke_closure.md#6-含-unary-的契約覆蓋與全-n2-的55化約)、[unary盾弧定理A](c5_unary_shield_budget.md#3-定理-a全圖至多兩份-unary-分量) |
| 多block U的每個leaf block有私有r-contact | [末端引理1](c5_excess_two_arc_spoke_closure.md#3-末端-block-必有私有-root-接點原-unit-unary-不存在) |
| 每奇環block至多一個普通私有點：非U割點且不接r | [三列共同附件及原minor](c5_excess_two_arc_spoke_closure.md#2-同一原分量在三列下的-block-附件一致性) |
| H內度二點的實際框邊附件單射 | [大小界引理2](c5_excess_two_arc_size_bound.md#3-每條原框邊至多承擔一個內度二點) |

外部輸入為 [Dvořák 2018，Lemma7／Theorem10](https://iuuk.mff.cuni.cz/~rakdver/barevnost/gallai.pdf)
的degree-list緊性及blockwise uniform刻畫，本輪重新核讀。
三列出口及下列case split是本輪推導，不歸稱外部定理原文。
不使用未證E-ARC2、雙缺額SD-A、ES／ER下界或Δ門檻。

## 2. 三列 palette signatures

反設D∈F_U(i)對每個i∈{0,1,3}成立。固定owner r=D，原lists為

\[
L_i(v)=[4]\setminus\bigl(q_i(N_B(v))\cup\{D:rv\in E(G)\}\bigr).
\]

這是原U局部存在性查詢，不要求r=D已有G−U外部染色。
完整degree4給degree assignment；不可染給tight lists及各原block palettes。
bridge palette大小1、奇環palette大小2，同點incident palettes互斥，聯集為Lᵢ(v)。
所以D∈Lᵢ(v) **恰當且僅當v不是r-contact**。此判定三列一致，其他色可隨列不同。

對原框邊e，Tᵢ(e)是該列三個已用色中未在e出現的那一色，三列順序為(0,1,3)。

| e | T(e) | 框點b | q(b) |
| --- | --- | --- | --- |
| 01 | (2,2,2) | 0 | (0,0,0) |
| 12 | (0,0,2) | 1 | (1,1,1) |
| 23 | (0,1,1) | 2 | (2,2,0) |
| 34 | (0,1,0) | 3 | (1,0,2) |
| 40 | (1,1,2) | 4 | (2,2,1) |

**signature引理1。** T(e)、T(f)若逐列異色，忽略順序只有{01,23}或{01,34}。
第三已用色的signature分別為(1,0,0)或(1,0,1)，均不是任何實際框點的q(b)。
全部25有序edge pairs中只有4個逐列異色。

**signature引理2。** 三個不同原框邊e₁,e₂,e₃，不存在逐列已用色cᵢ，
使全部Tᵢ(eⱼ)異於cᵢ，而且每個剩餘第三色都來自一個同一原框點hⱼ。
十個無序三邊集合有八個在某列的T色集合已等於{0,1,2}，無cᵢ。
其餘兩個如下：

| 三原框邊 | 逼定c=(c₀,c₁,c₃) | 某個所需框點signature | 結果 |
| --- | --- | --- | --- |
| 12,23,40 | (2,2,0) | 40所需(0,0,1) | 無實際框點 |
| 12,34,40 | (2,2,1) | 12所需(1,1,0) | 無實際框點 |

这里只算五條字面框邊／五個字面框點，沒有逐件D₅正規化或代換原附件。

## 3. 任意大小 block tree 的化約

**cycle引理。** k≤3時U的每個奇環block都是triangle。
若triangle含r-contact，則沒有普通私有點，contact不能是環上的U割點，
且已耗盡三個contacts作其三個terminal directions。

*證明。* 固定原奇環K。其每個U割點x在環外至少有一個分支，沿block tree走到
環外leaf block，可取該leaf私有r-contact。不同x的分支互斥，所取contacts不在K，
也不同於K上的私有contacts。普通私有點最多一個，故

\[
|K|\le1+\#\{K\text{上的U割點}\}+\#\{K\text{上的私有contacts}\}\le1+k\le4.
\]

奇環只能長3。若K含contact，D不在K的palette；若有普通私有點，其唯一incident
palette等於Lᵢ(v)，必含D，矛盾。三個環點因此都為割點或私有contact，其三個directions
至少耗三個不同contacts。割點本身再為contact就需第四個，超過k。
故k=3，contacts均私有，環外各方向恰一個contact、沒有額外分枝。
無contact而有三割點的triangle同樣耗三個環外contacts。∎

稱有兩U割點、一普通私有點且無contact的triangle為普通環。
其普通點z的原框附件是邊f，環palette每列恰為{D,Tᵢ(f)}。
這不替換原triangle，全圖及所有原座標仍保留。

**末端檢查。** leaf bridge私有端p接r，其原框附件為邊e，bridge palette每列
必為{Tᵢ(e)}。在沒有額外contact／branch的末端鏈上：

1. 鄰點w不接r且只incident兩bridges時，w框附件是邊f，Lᵢ(w)={D,Tᵢ(f)}。
   逼T(e)=T(f)，故e=f；p,w均為原H內度二點，違附件單射。
2. w只再incident普通環時，w框附件是一個原框點h。bridge Tᵢ(e)與cycle
   {D,Tᵢ(f)}互斥，qᵢ(h)必為其第三已用色；signature引理1排此同一h。
3. w只再incident含contact的特殊triangle時，該環palette不含D而Lᵢ(w)含D，
   bridge palette就必為D，違leaf端的{Tᵢ(e)}。

每步只核原leaf邊及原鄰點，沒有刪掉中間鏈後再宣稱relation不變。
它們迫bridge末端直接抵達剩餘contact或唯一branch，不能有未計旁支。

## 4. k=2／3 的完整分支覆蓋

多block U的每個leaf block至少一個私有contact，block-cut tree有2或3個leaves。
cycle leaf在D拒絕下至少兩私有contacts。以下互斥且窮盡；長鏈的第一個原鄰點由
§3末端檢查處理，不從有限短圖外推。

### 4.1 單一block

singleton unary完整degree不足四。單bridge兩點均須接r且各接框邊e、f；
不可染迫T(e)=T(f)，所以e=f，兩個H內度二點違單射。
單cycle若有普通點及contact，D的palette判定矛盾；若全為contacts，只能是k=3 triangle。
三个lists相同迫三個原框點附件的三列色相同，框點signature互異迫actual support只有一點，
違unary支援至少三點。

### 4.2 兩個leaf blocks

block-cut tree是一條路徑。有cycle leaf時，其兩私有contacts加另一bridge leaf的contact
已用盡k=3；兩cycle leaves則需至少四contacts。cycle leaf是含contact的特殊triangle。
bridge末端若先碰普通bridge cutpoint、普通環，或直接鄰特殊環，分別被末端檢查1、2、3排除。

故兩leaves均為bridges，私有端各一contact。k=2無第三contact或特殊環；除單bridge外，
一端鄰點必為普通bridge cutpoint或普通環cutpoint，均已排。
k=3時第三contact若在cycle上，cycle引理使其只能是兩割點特殊triangle的私有點，
两端末端鏈再由同三步排除。第三contact若不在cycle上，只能是兩bridges間原割點w。
兩端必直接鄰w，否則某端首先碰普通bridge cutpoint／普通環。
故只剩 **p–w–q三點路徑，三點全接r**：端點接框邊e、f，w接一個框點h。
兩bridge palettes逐列互異，qᵢ(h)為第三已用色，signature引理1排除。

### 4.3 三個leaf blocks

三contacts全在三個leaf私有端，leaves全為bridges，無其他contact。
block-cut tree恰一個degree3 branch node，其餘為鏈。

- branch為原割點：完整degree≤4，三incident blocks只能是3bridges或cycle+2bridges。
  三bridge時各末端鏈不能有普通bridge cutpoint／普通環，故三contact端都直接鄰此割點。
  三palettes全不含D，而割點不接r、Lᵢ含D，矛盾。
  cycle+2bridges時，cycle是具有另一割點及普通私有點的普通triangle；第三末端若有
  中間鏈由末端檢查1／2排，若直接鄰cycle另一割點由末端檢查2排。
- branch為cycle block：它是三個環點都為割點的triangle。三末端鏈仍不得有普通bridge
  cutpoint／普通環，故各割點直接接contact葉pⱼ。葉的三原框邊eⱼ互異（H內度二附件單射），
  割點各只接一個原框點hⱼ。若cycle palette不含D，三bridges都必取D，違葉端palette。
  所以cycle palette為{D,cᵢ}，每個Tᵢ(eⱼ)異於cᵢ，qᵢ(hⱼ)是第三已用色。
  signature引理2排此全部三邊選擇。

全部單block、兩leaf、三leaf均矛盾；原環間bridges、共享割點、任意鏈長及cycle上的
第三contact都有覆蓋。因此得到完整紙面候選

\[
\boxed{\exists i\in\{0,1,3\}:\quad D\notin F_U(i).}
\]

## 5. 同列接回與剩餘義務

若(ℓ,u)=(0,1)，取上式的同一i。r=s=D避開全部原spokes，原rs不存在；U有owner=D的
完整lift。[N-diagonal](../artifacts/c5_excess_two_e4/REPORT.md#41-新引理-n-diagonal只指定-nc-的局部-list-版本)
給两short P,Q在該同一qᵢ／同一(D,D)的完整lifts。三原分量互斥，可接成原G完整染色，
包括原shared contacts及自由孤立四色因子，違qᵢ拒絕。

本輪交付的是該子族的**紙面排除候選**，沒有另人獨立採納或target有限排除證書。
統一報告四情形採納表保留並加候選入口。若採納，與已有u=2排除合併即可覆蓋
第三relation族的原55格；九格將由六格已有覆蓋增加至七格，但本輪不改採納計數。
下一窄義務將剩下：

| 情形 | 仍需證的同列充分條件 |
| --- | --- |
| (2,0) | 兩long在同一指定列接受(D,D)，或其他完整joint非空 |
| (1,0) | long在同一指定列接受(D,D)，或其他完整joint非空 |
| (1,1) | U escape列中long也接受(D,D)，或另一同列完整joint非空 |

不能拼U某列escape與long另一列的diagonal。Δ門檻路線仍OPEN、上下界不改；
u=0的singleton mixed可能性及其餘long分支不受候選覆蓋。

## 6. Checker、負控制及證據界線

[Checker](../audits/2026-10-11-n2-unary-three-row-escape/checker.py)只讀兩份既有固定產物，
保留原63圖全部97份U、ordered roots／頂點／region edges／actual attachments。
numeric-order DFS重算全部十列完整16-pin fibres，逐tuple對回component-slack原檔；
新產物保存全部lifts及空cells，沒有用F_U marginals代替證據。原disk／rotation沿用來源，未重驗。

| 核對 | 結果及範圍 |
| --- | --- |
| 97原U | 970列、15,520 ambient cells、2,048空cells，逐tuple一致 |
| 新局部前提 | 42份triggered and holds（全k=2），55份not triggered |
| 三列signature表 | 25有序edge pairs／4逐列異色、10異邊triples／0可行三列中央triangle |
| k=3同一U控制 | p–w–q全接r，p接01、w接3、q接23；q₀/q₁禁D、q₃接回，triggered and holds |
| 撤掉附件單射 | 原edge兩點同接r及01，三列均禁D；counterexample，非target來源 |
| 撤掉U跨度 | 原triangle三點同接r及框點0，三列均禁D；counterexample，非target來源 |
| 完整Σ933／941 N2來源 | 0張，not triggered；沒有source realization／有限來源全排 |

三份具名局部控制各保存完整十列160 cells，沒有宣稱它們是disk、Σ-critical或雙degree5來源。
任意大小量詞由§3–4紙面case split承擔，checker不核其完備性。
作者第二次量詞／branch核對見 [AUTHOR_REVIEW](../audits/2026-10-11-n2-unary-three-row-escape/AUTHOR_REVIEW.md)，
**不是另人獨立採納**。具體產物與驗證見 [REPORT](../audits/2026-10-11-n2-unary-three-row-escape/REPORT.md)。

本輪normal／seed17重播均exit0、產物bytes／SHA相同；故意毀損副本按預期exit1、
`artifact mismatch`。`check_docs`、正式docs DocGraph及`git diff --check`通過；
`lake build`通過8,831 jobs，保留既有linter warnings。Build不形式化此紙面候選。

```bash
python3 -B audits/2026-10-11-n2-unary-three-row-escape/checker.py --check
PYTHONHASHSEED=17 python3 -B audits/2026-10-11-n2-unary-three-row-escape/checker.py --check
python3 -B scripts/check_docs.py
python3 -B tools/docgraph --include 'docs/**/*.md' check
lake build
git diff --check
```

未重跑上游全部44／N45／SD-A、ES／ER搜尋、含凍結副本的全樹DocGraph。
未新增Lean證明。文件傳播止於統一報告、Kempe導覽、STATUS、N45直接入口及已有synthesis摘要；
README／HANDOFF路由未變，核對後不加逐輪摘要。舊採納表不因候選自動改成CLOSED。
