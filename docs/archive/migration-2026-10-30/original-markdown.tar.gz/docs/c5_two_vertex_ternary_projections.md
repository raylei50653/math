# C₅ 兩混合框的全部三點投影：16 個殘留軌道與四點下界

**2026-10-02 形式化後續：** [NamedRepair](lean_named_repair.md) 已補兩個核心的
具名原圖 J、指定兩框 P、完整 W／C 及 repair 分類。指定框 P 的 r*=4 已由 NamedRepair 形式化；完整三點投影表及殘留計數仍為 Python。
下文保留原輪次的計算與證據界線；disk 框完備性仍未 Lean 化。


**2026-09-30 後續：**[四點投影最小修復](c5_two_vertex_quaternary_repairs.md)
已遍歷全部 70 個 scope 與 2,415 個配對，證成最少兩份且只有本報告
給出的那一組。下文保留本輪 arity 下界與尚未分類投影個數的原語境。

2026-09-30。接續[兩框共同拉回與精確修復](c5_two_vertex_mixed_pullback.md)，
只處理同一 `private_interiors_reverse` 十五點三十五邊原圖。
**兩框加上原 J 的全部 56 個三點投影仍不等於 J：保留 76 軌道／
1,824 份賦色，多出 16 軌道／384 份。** 其效果恰等於補回原邊
b2–b4，沒有排除任何通過原 U 邊的舊假接受列。

在原八點上以局部條件的合取修復兩框、且不引入輔助變數的模型中，
新增條件的最小最大 arity 恰為四。下界是全部三點投影仍不足；上界
是兩個指定四點投影已足夠。這不聲稱投影個數或所有表示法的最小性。
證據為 Python 固定圖完整證書及紙面關係推導；未新增 Lean theorem。
目前停止點由[兩點重疊導覽](c5_two_vertex_overlap_guide.md)維護。

## 1. 原圖、具名範圍與問題

來源仍為 R127 `(0,2)` 接 R167 `(3,1)`，識別 a0=b3、a2=b1；
全部原邊、七個私有內點與同一顏色集合 `D={0,1,2,3}` 保留。

```text
U  = (a0,a1,a2,a3,a4,b0,b2,b4)
C₁ = (a0,a4,a3,a2,b2)   indices (0,4,3,2,6), relation R255
C₂ = (a0,b4,b0,a2,a1)   indices (0,7,5,2,1), relation R1022
```

令 J 為原圖在 U 上的完整可延拓關係，P 為兩框關係沿具名映射的
共同拉回。對每個三元素子集 S⊆U，以 U 的原欄序排列，定義

\[
T_3(J)=\{u\in D^U:\ \forall S\in\tbinom U3,\ u|_S\in\pi_SJ\},
\qquad Q=P\cap T_3(J).
\]

每份投影包含全部具名顏色 tuples。Membership 不把各個三點 tuple
獨立標準化後拼接；證書中的軌道代表只用於同一 U 上的共同 S₄ 換色。
所有三點投影均從原邊回溯重建的 J 計算，不從 P 或修復公式推測。

## 2. 全部三點投影只保留原邊

固定圖的精確計算結論為

\[
\forall S\in\tbinom U3,\qquad
\pi_SJ=\operatorname{Col}_4(G[S]).
\]

右側只要求 S 內的原邊兩端異色。Checker 對每個 S 比對兩邊的完整
tuples，包含全部 `4³=64` 個候選；沒有只比較基數。
56 份完整關係、具名欄序、原誘導邊及它們從 P 排除的全部賦色均在
[證書](../artifacts/c5_two_vertex_overlap/ternary_projections.json)。

| 三點原誘導邊數 | 三點 scope 數 | 每份投影的具名賦色數 |
| --- | ---: | ---: |
| 0 | 11 | 64 |
| 1 | 25 | 48 |
| 2 | 19 | 36 |
| 3 | 1 | 24 |

每條 U 內原邊都落在某個三點集合，故上述完整等式給出紙面推論

\[
T_3(J)=\operatorname{Col}_4(G[U]).
\]

P 已保留 U 上十一條原邊中的十條，唯一漏掉 b2–b4，因此

\[
\boxed{Q=P\cap\{u:c_{b2}\ne c_{b4}\}.}
\]

全部 56 個 scopes 中，50 個在 P 上不再排除任何列；六個包含
`{b2,b4}` 的 scopes 都恰排除同一份 38 軌道／912 份賦色。
另從 J 獨立計算全部 28 個二點投影，與 P 合取後也得到同一 Q。

| 關係 | 全域 S₄ 軌道 | 具名賦色 |
| --- | ---: | ---: |
| P | 114 | 2,736 |
| P 加全部二點投影 | 76 | 1,824 |
| Q：P 加全部三點投影 | 76 | 1,824 |
| 原 J | 60 | 1,440 |
| Q∖J | 16 | 384 |
| J∖Q | 0 | 0 |

以上 rows 至少使用三色，故全域 S₄ 軌道大小皆為 24。

## 3. 全部殘留列與逐三點延拓

沿用前報告的兩條四點條件

\[
G_A:\ |\{c_{a0},c_{a1},c_{a2},c_{a3}\}|\le3,
\qquad
G_B:\ c_{a2}\ne c_{b4}\ \lor\ c_{b0}=c_{b2}.
\]

Q∖J 的全部 16 個軌道代表如下；每列按 U 次序讀取。

| 恰好失敗 | 軌道代表 |
| --- | --- |
| G_A，6 個 | `01232013`, `01232031`, `01232112`, `01232113`, `01232331`, `01232332` |
| G_B，8 個 | `01201132`, `01201312`, `01202132`, `01202312`, `01203132`, `01203312`, `01212132`, `01212312` |
| G_A、G_B，2 個 | `01232132`, `01232312` |

證書對**每個軌道的每個三點 scope** 保存一份原十五點正常染色，
在該三點上逐一等於原列顏色；總計 `16×56=896` 份。
Verifier 要求 56 個 scopes 完整、不重複，逐份核對所固定顏色與
全部 35 條原邊。對整份十五點 witness 施同一 S₄ 作用後，另外
核對 `384×56=21,504` 份具名延拓。

每個殘留軌道也保留前輪的兩份單框原圖延拓與每條失敗條件的原邊
拒絕證明。全部 384 份差集賦色明列保存，不以例子代替完整差集。
每份三點 witness 的八點 restriction 都不同於被拒絕的原列：
逐份存在延拓，不給出共用一份完整八點賦色的延拓。

例如 A-only 列 `01232013` 在 `(a0,a1,a2,a3)` 用滿四色。
原鄰點依序迫 `A_inner9=3`、`A_inner5=1`、`A_inner7=1`，
違反原邊 `A_inner5–A_inner7`。它的全部三點投影及兩個混合框
仍各有原圖正常染色。B-only 列 `01201132` 則令 a2=b4=2、
b0=1、b2=3，原附件迫 `B_inner5=B_inner6=0`，違反兩內點原邊。
Checker 保存並逐步驗證每個殘留列的相應拒絕證明。

## 4. 新增條件所需的最大 arity 恰為四

### 三點下界適用於任意局部條件合取

假設某個候選表示為

\[
J(u)\iff P(u)\land\bigwedge_i H_i(u|_{S_i}),\qquad |S_i|\le3,
\]

其中 H_i 是原 U 顏色上的任意關係，沒有額外變數，合取必須保留
全部 J。則對每個 i 必有 `π_{S_i}J⊆H_i`。若 |S_i|<3，可將它
包含在某個三點 scope 中，所以每份 Q row 仍滿足 H_i。
因此 Q 必包含於該候選表示；但 Q∖J 非空，矛盾。

這把「三條既有 guards 不可省略」提升為「任何這類最大 arity≤3
的修復都不足」，即使 H_i 不要求 S₄ 不變也成立。結論限制於局部
條件的**合取**與原八點變數，不涵蓋一般 Boolean 組合、帶存在量詞
的輔助變數、或丟棄舊接口後改變未來可接觸範圍的模型。

### 兩個具名四點投影給出上界

取

```text
S_A = (a0,a1,a2,a3)   indices (0,1,2,3)
S_B = (a2,b0,b2,b4)   indices (2,5,6,7)
```

完整投影分別為

| 投影 | 全部 S₄ 軌道代表 | 具名賦色 |
| --- | --- | ---: |
| π_{S_A}J | `0101`, `0102`, `0120`, `0121` | 84 |
| π_{S_B}J | `0110`, `0112`, `0123` | 60 |

第一個投影給出 G_A 與其原邊；第二個投影同時給出 G_B、b2≠b4
及其餘原邊。因此依前報告的精確修復式，也由完整集合重算驗得

\[
\boxed{J=P\cap\pi_{S_A}^{-1}(\pi_{S_A}J)
          \cap\pi_{S_B}^{-1}(\pi_{S_B}J).}
\]

這裡無須額外加入 56 份三點投影。即使先加入全部三點投影，再
省略第一個四點投影仍多 6 軌道；省略第二個仍多 8 軌道。
此輪沒有分類其餘四點 scopes，也不宣稱兩份是所有選擇中的最少個數。

## 5. 重播、證據層與保留範圍

[Checker](../scripts/c5_two_vertex_ternary_projections.py)只使用標準函式庫，
SHA-256 綁定前輪拉回證書、原來源及 verifier 鏈與自身。
原 J 從七內點回溯重建；P 從具名 natural join 重建；Q 由 P 篩選
及全部 `4^8` 查詢兩路徑核對。全程共用原具名色框與原圖。

```bash
python3 scripts/c5_two_vertex_ternary_projections.py
python3 scripts/c5_two_vertex_ternary_projections.py --check
PYTHONHASHSEED=17 python3 scripts/c5_two_vertex_ternary_projections.py --check
python3 scripts/c5_two_vertex_mixed_pullback.py --check
python3 scripts/c5_two_vertex_join.py --check
lake build
python3 scripts/check_docs.py
python3 tools/docgraph check
git diff --check
```

六項 verifier 負控制每次重播皆須拒絕：漏掉一個三點 scope、修改
其固定顏色、延拓違反原邊、把三點延拓當成八點延拓、漏掉合法
投影 tuple、加入不可延拓 tuple。實際重跑與未重跑範圍見
[本輪紀錄](history/2026-09-30-c5-two-vertex-ternary-projections.md)。

本輪完成此固定 J 的三點不足與四點 arity 上下界，未搜尋新來源圖、
外框或環序；未改動拓撲證書。一般 class-pair 後繼、多步同餘、
完整 Σ 的一般壓縮定理與 `K∞=K≤5` 均未證。沒有新增外部定理依賴、
Lean 或 `native_decide` 證明；`lake build` 只驗既有 Lean。
