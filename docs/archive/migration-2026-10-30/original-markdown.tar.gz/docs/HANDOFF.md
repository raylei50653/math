# 研究工作入口

初次接手先讀[研究總覽](research_overview.md)；已有問題時，直接選要完成的工作。

<a id="2-精確停止點與下一個窄問題"></a>

- [接續四色證明研究：問題、契約與第一個工作](4ct_guide.md) #進行中
- [執行求解與實驗：消元、共同回填及比較](four_color_guide.md)
- [驗證證據：Lean 定理、公理與形式化範圍](lean_guide.md)
- [調用既有成果：接口、結構引理及使用前提](reference/results_guide.md)
- [查閱封存：歷史工作、原始報告與後續涵蓋](archive/archive_guide.md)
- [接續獨立交叉數研究：局部重畫與旋轉限制](zarankiewicz_guide.md)

`#進行中` 標記正在推進的研究線；工具、驗證與成果查找供當輪按需使用。
C₅ 各線的完整導覽由成果查找入口連入；封存不表示結論失效，未解義務仍以權威來源為準。
[完整文件索引](STATUS.md) · [文件治理與工作約定](DOCUMENTATION.md)
