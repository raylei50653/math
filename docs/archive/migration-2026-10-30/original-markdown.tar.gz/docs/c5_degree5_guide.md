# degree-5／R 系列導讀：介面、排除範圍與保留缺口

## 最新進度

現況核對：2026-10-13；本次只整理入口，未新增研究結論。

| 欄位 | 現況 |
| --- | --- |
| 階段／生命週期 | 指定 degree-5 分支與後續 N2 契約已有排除成果；一般 degree-5／R31 來源 minor 義務保留 OPEN，未由子域收尾推升。 |
| 最近研究更新 | 2026-10-13：[LL-CUT+diag 完整 N2 九格覆蓋](c5_excess_two_n2_ll_cut.md)，以及 [N2-BRIDGE 原 E4 三列契約橋接](c5_excess_two_n2_bridge.md)。 |
| 上次完成 | 二連通單缺額已查證；後續在指定完整 N2 前提排除 spoke45／54，再涵蓋原55。N2-BRIDGE 另承擔原 E4 三列契約的移植證明。 |
| 目前停止點 | R31 同末端不同二接點僅正常形完成，任意長來源 minors 待補；未覆蓋來源及一般出口 OPEN。基本 LL-CUT 的獨立觸發機制仍未證成。 |
| 下一步 | 接續時補 R31 任意長奇環及重複色外臂的 boundary 固定來源 minors，逐步核對 degree、四列、刪邊著色，再合成正常形拓撲證書。 |
| 接手入口 | [R31 精確停止點](c5_degree5_same_terminal_triangles.md#4-精確停止點)與本頁 §4；N2 後續見 [Kempe 導覽](c5_kempe_guide.md)，一般出口見 [weak-deletion 導覽](c5_weak_deletion_guide.md)。 |

### 近期里程碑

| 日期／階段 | 進展與來源 |
| --- | --- |
| 2026-09-18／R24–R31 | [雙環](c5_degree5_shared_cycle_minors.md)及指定三環來源型陸續完成；[R31](c5_degree5_same_terminal_triangles.md)停在同末端不同二接點正常形，任意長來源義務保留。 |
| 2026-09-28／雙列分離接入 | 唯一 degree-5 全部核心的指定雙列分離接回[條件式單側出口](c5_single_sided_exit.md)；一般完整 Σ 及 R31 minor 缺口保留。 |
| 2026-10-11／單缺額與共用排除 | [二連通單缺額查證](c5_degree5_interfaces.md#7-二連通單缺額查證與-4554-接入)及[雙色唯一缺口推論](c5_two_color_single_gap_bridge.md)接入指定 N45 域。 |
| 2026-10-13／N2 契約收尾 | [LL-CUT+diag](c5_excess_two_n2_ll_cut.md)完成指定完整 Σ 九格；[N2-BRIDGE](c5_excess_two_n2_bridge.md)另排原 E4 三列契約 N2。基本 LL-CUT、N1／相鄰分支及一般 R31 不由此完成。 |

本頁維護 R9–R31 的來源結構、minor 與單缺額查證情況。
研究線標記見 [HANDOFF](HANDOFF.md)，全索引見 [STATUS](STATUS.md)。
前置依賴見 [全 degree-4 導覽](c5_degree4_guide.md)。

舊摘要數字與證書仍見原報告及 [九組成果發布紀錄](history/2026-09-28-adjacent-progress-publish.md)。
R9–R31 為研究輪次，不是報告參考文獻編號。

## 1. 目前完成到哪裡

**二連通單缺額結構已查證。** 有限簡單 induced-C5 disk M 中，H=M−B 二連通，
唯一內點 s 完整 M-degree5、其餘4；任意 proper β 拒絕即得 d_H(s)=2、H−s Gallai tree。
不需 minimality、T4 或 lists 全緊；[精確定理與外部依賴](c5_degree5_interfaces.md#7-二連通單缺額查證與-4554-接入)
保留紙面／有限控制／Lean 界線。對45／54的應用見[N45§2.11](c5_excess_two_nonadjacent_unit_core45.md#211-單缺額查證與無-u-二連通子域)，
原適用性查證須另核實際 X=M、完整 degrees 與二連通。
後續[末端block與兩次SD-A](c5_excess_two_arc_spoke_closure.md)已在完整N2目標前提
證無U的H二連通，排全部spoke45／54；含U接既有契約後，N2只剩原55。
後續[LL-CUT+diag](c5_excess_two_n2_ll_cut.md)完成指定完整Σ契約內的原55九格覆蓋。
這不完成一般degree5／R31或較廣N2，也不能把單缺額SD-A套到原55。

**一般 degree-5 排除仍未完成。** 在唯一 degree-5 內點 z 有三條 boundary
spokes、C=H−z 為連通二接點分量、其餘有效內點完整 degree=4，且來源是
接受全部 T4 的 C5 disk minimal q-obstruction 的指定前提下，已有：

| 分量或接點型 | 現況與結論入口 |
| --- | --- |
| 樹；恰一個 odd-cycle block，其餘 bridges | [R12](c5_degree5_tree_components.md)、[R13–R14](c5_degree5_odd_cycle_components.md) 任意大小排除 |
| 恰兩個 odd-cycle blocks，其餘 bridges | 互斥型 [R22](c5_degree5_two_long_cycles.md) 與共用點型 [R24](c5_degree5_shared_cycle_minors.md) 合成完成；環長、外臂不限 |
| 三環共用點鏈，兩臂各在末端私有點 | [R27](c5_degree5_three_cycle_minors.md) 任意長來源 minors 與拓撲合成完成 |
| 同一三環鏈，兩個不同私有接點在中間環 | [R29–R30](c5_degree5_middle_cycle_minors.md) 正常形及任意長來源排除完成 |
| 同一三環鏈，兩個不同接點在同一末端環 | [R31](c5_degree5_same_terminal_triangles.md) 僅完成正常形；任意長來源 minors 待補 |
| 末端與中間、同點會合、環間 bridge、一般三環／更多環、其他 degree-5 分拆 | 未由上述指定型排除涵蓋 |

三環共用點鏈指 J1∩J2={r12}、J2∩J3={r23}、J1∩J3=∅、r12≠r23。
表中是各篇紙面化約與有限證書的合成範圍；詳細前提以原報告為準。
[R9](c5_k4_blocks.md) 的全 degree-4 **整圖**結論不能直接套到帶 z 的分量。
R31 是保留缺口；是否進行中見 HANDOFF；本線停止點見 §4。

## 2. 符號與證據界線

- R10 對任意 proper boundary row b 定義共同接點關係 R_C(b)、禁色 F_C(b)
  與 z 的可用色 A_z(b)。精確接合為 `Z_G(b)=A_z(b) \ ⋃_C F_C(b)`；
  可延拓 iff Z_G(b) 非空。同一分量的端點 marginals 不能相乘代替共同關係。
- R11 起聚焦三-spoke 分拆 (2)：z 剩餘兩條內邊進入同一分量 C。
  原框 q=(A,B,A,B,C)，D 為第四色；區域框 (z,b1,b2,b3,b4) 的 D 列為
  (D,B,A,B,C)。這個區域重寫不自動接受全部 T4。
- 固定 q 的「四列」是逐一查詢 C 配合四個 z 色，暫不施加 z–B spokes；
  須保留完整 F_C(q)，不能只驗拒絕 D。
  它不等於全部 boundary rows 的完整 Σ，亦不保證完整 root 關係或任意 pinning。
- 介面等價、有限正常形非 disk 覆蓋、任意長來源的 boundary 固定 minor
  是不同證據步驟。須保留實際 attachments、共同色框、degree、逐邊刪除著色，
  並將正常形拓撲證書合成回同一來源圖。
- 任意大小推論依原報告的紙面化約及所引用的外部 degree-list 定理；
  Python 保存固定域控制／minor 證書。[Lean 接合基礎](lean_root_interfaces.md)
  支援一般代數步驟，未形式化整套 Gallai／disk／來源 minor 論證。

## 3. R9–R31 閱讀與後續對照

先讀 R9–R11 確认整圖與分量的差別，再按需要選零／一環、雙環或三環分支。
以下各列記錄報告的保留用途；已被後續補完的舊停止點不另列為待辦。

| 輪次與報告 | 成果及後續關係 |
| --- | --- |
| [R9：全 degree-4 合成](c5_k4_blocks.md) | K4 排除與既有 block 分類合成；唯一 degree-5 的完整介面由 [R10](c5_degree5_interfaces.md) 接續。 |
| [R10：完整多接點介面](c5_degree5_interfaces.md) | 染色與 minimality 介面已完成；[R11](c5_degree5_sectors.md) 起處理三-spoke 分拆 (2)，一般 degree-5 幾何排除仍開放。 |
| [R11：三-spoke 區域定位](c5_degree5_sectors.md) | 兩個鏡像 pentagon 化約保留；[R12](c5_degree5_tree_components.md) 至 [R24](c5_degree5_shared_cycle_minors.md) 已處理零／一／二環，分拆 (2) 整體仍開放。 |
| [R12：任意樹與 K4 引理](c5_degree5_tree_components.md) | 任意樹排除完成；單環由 [R13–R14](c5_degree5_odd_cycle_components.md)、雙環由 [R15–R24](c5_degree5_shared_cycle_minors.md) 接續完成。 |
| [R13：單 triangle](c5_degree5_triangle_components.md) | 指定單 triangle 分量排除完成；[R14](c5_degree5_odd_cycle_components.md) 已補任意單奇環。 |
| [R14：任意單奇環](c5_degree5_odd_cycle_components.md) | 單奇環加 bridges 排除完成；雙環由 [R15–R24](c5_degree5_shared_cycle_minors.md) 接續完成。 |
| [R15：共用點雙 triangles](c5_degree5_shared_triangles.md) | 共用點型排除完成；互斥 triangles 由 [R16–R19](c5_degree5_bridge_mark_minors.md)、共用點長環由 [R23–R24](c5_degree5_shared_cycle_minors.md) 補完。 |
| [R16：互斥 triangles 的 bridge](c5_degree5_bridge_triangles.md) | 直接私有接點與旁支化約保留；任意外臂及同點接入由 [R17](c5_degree5_bridge_arms.md) 與 [R18–R19](c5_degree5_bridge_mark_minors.md) 補完。 |
| [R17：不同環點的任意外臂](c5_degree5_bridge_arms.md) | 不同環點接入排除完成；至少一側同點接入由 [R18–R19](c5_degree5_bridge_mark_minors.md) 補完。 |
| [R18：同點標記介面](c5_degree5_bridge_marks.md) | 標記介面與正常形保留；[R19](c5_degree5_bridge_mark_minors.md) 已補真正來源 minors 及完整接線拓撲覆蓋。 |
| [R19：同點來源 minors](c5_degree5_bridge_mark_minors.md) | 結合 R15–R17 完成恰兩個 triangles；含長環的雙環由 [R20–R24](c5_degree5_shared_cycle_minors.md) 補完。 |
| [R20：長環加 triangle 的四列介面](c5_degree5_long_triangle_roots.md) | 完整條件 root 介面保留；[R21](c5_degree5_long_triangle_minors.md) 已補混合雙環來源 minors 與圖層排除。 |
| [R21：混合雙環來源 minors](c5_degree5_long_triangle_minors.md) | 互斥混合雙環排除完成；[R22](c5_degree5_two_long_cycles.md) 補雙長環，[R24](c5_degree5_shared_cycle_minors.md) 補共用點型。 |
| [R22：互斥雙長環](c5_degree5_two_long_cycles.md) | 互斥雙奇環任意長度排除完成；共用點型由 [R23–R24](c5_degree5_shared_cycle_minors.md) 補完。 |
| [R23：共用點四列介面](c5_degree5_shared_cycle_roots.md) | 四列布林縮環與完整 root 不保持的控制保留；[R24](c5_degree5_shared_cycle_minors.md) 已補圖層來源 minors 及排除。 |
| [R24：共用點雙奇環來源 minors](c5_degree5_shared_cycle_minors.md) | 結合 R22 完成恰兩個 odd-cycle blocks；指定三環鏈由 [R25–R27](c5_degree5_three_cycle_minors.md) 接續，一般三環仍開放。 |
| [R25：末端各一臂的三環介面](c5_degree5_three_cycle_roots.md) | 完整有序接合保留；[R26](c5_degree5_three_triangles.md) 完成正常形，[R27](c5_degree5_three_cycle_minors.md) 完成此型任意長來源 minors。 |
| [R26：末端各一臂正常形](c5_degree5_three_triangles.md) | 正常形拓撲覆蓋完成；[R27](c5_degree5_three_cycle_minors.md) 已補此型任意長來源 minors 及拓撲合成。 |
| [R27：末端各一臂來源 minors](c5_degree5_three_cycle_minors.md) | 末端各一臂的共用點三環鏈排除完成；其他位置見 [R28](c5_degree5_three_cycle_positions.md)，一般三環仍開放。 |
| [R28：三環鏈全部接點位置](c5_degree5_three_cycle_positions.md) | 完整 list 接合保留；[R29–R30](c5_degree5_middle_cycle_minors.md) 已完成中間不同二接點排除，[R31](c5_degree5_same_terminal_triangles.md) 僅完成同末端不同二接點正常形。 |
| [R29：中間二接點 C3–C5–C3](c5_degree5_middle_pentagon.md) | 正常形拓撲覆蓋完成；[R30](c5_degree5_middle_cycle_minors.md) 已補中間不同二接點的任意長來源 minors。 |
| [R30：中間二接點來源 minors](c5_degree5_middle_cycle_minors.md) | 中間不同二接點鏈型排除完成；[R31](c5_degree5_same_terminal_triangles.md) 已完成同末端不同二接點正常形，該型任意長來源 minors 仍待補。 |
| [R31：同末端不同二接點正常形](c5_degree5_same_terminal_triangles.md) | 408 模板／327,968 接線的正常形非 disk 覆蓋完成；任意長來源 minors 仍是保留缺口，不能宣稱此型已任意長排除。 |

## 4. R31 保留缺口與重播入口

**雙色唯一缺口的共同推論（2026-10-11）：**
[一般定理與完整證明](c5_two_color_single_gap_bridge.md)不依 N45 名稱或四色限制。
不可著色 degree lists 下，完整 S 僅 q 含 T 缺 D、其餘 lists 含 T/D，
迫唯一 r-contact 與 r–q 全 bridge 路徑。對同一原 M 的 degree／拒絕／完整延拓，
actual 異色 pair、唯一 s-contact q 加至少兩個 r-contacts 即矛盾，
[N45§2.12](c5_excess_two_nonadjacent_unit_core45.md#212-雙色唯一缺口的共同排除)逐份接回1a／1c／1e／1g。
任意有限旁支數、位置、三環形狀及 private witness 不再是這份推論的必要前提。
本輪為外部 Gallai＋紙面證明，未另經獨立採納審查，無新有限來源或 Lean。
此共用引理本身未覆蓋單一r-contact、多個s-contacts、未證雙色lists的非pair support
或其他出口；但完整N2 exact-S已由後續[N45§2.14](c5_excess_two_nonadjacent_unit_core45.md#214-e-arc2-接入全部-spoke4554-排除與原55化約)
整體排除；指定完整Σ契約的原55另由[LL-CUT+diag](c5_excess_two_n2_ll_cut.md)涵蓋。
一般degree5／R31 minor、契約外原55及較廣N2保留。
下列四份既採成果保留其原合同與歷史證據；其中多旁支／其他形狀 OPEN 的敘述，
現在均須扣除上述共同前提完整成立的域。驗證及本地提交範圍見
[整理紀錄](history/2026-10-11-two-color-single-gap.md)。

BR-SD-1a／1c／1e 的任意大小 scoped exclusions 已獨立驗證、封存、發布並
[正式接入 N45§2.11](c5_excess_two_nonadjacent_unit_core45.md#211-單缺額查證與無-u-二連通子域)：
同為無 U／long／actual 真框邊 pair-short、split22、共用 r 雙環及原三環單 bridge 骨架；
**1a 僅排無旁支合同；1c 僅排一份原有限非空 W 只接 J1/J2，保未改動 J3／q 外臂；
1e 僅排一份原有限非空 W 唯一接 J3／q 外臂**，各保同一原 G／M、actual S pair support、
完整 degree及全部原資料。任意奇環／p、q 外臂長、有限 W 大小及所有允許接點／具名重合均涵蓋。
1e 由 J1/J2 private-witness preservation 排除，不依1c terminal lemma或 H_M 二連通；
兩個可重用局部引理各須完整前提，不能由 cutpoint list 含 D 推每個 incident palette 含 D。
完整父身份、多旁支、一般 Gallai block tree 仍 OPEN，完整 OPEN 身份新增無條件關閉數仍為0。
[1b 採納紀錄](history/2026-10-11-br-sd-1b-adoption.md) 與
[1d 採納／residual 紀錄](history/2026-10-11-br-sd-1d-adoption.md) 及
[1f 採納／custody 紀錄](history/2026-10-11-br-sd-1f-adoption.md) 保存各輪核對，與 R31 minor 義務分開。

**BR-SD-1g 已採納：** [原 PROOF](../audits/2026-10-11-br-sd-1g-dbdc4c35/PROOF.md) 經
[獨立採納審查](../audits/2026-10-11-br-sd-1g-adopt-6eae3597/REPORT.md) 通過並封存，
由 owner 批准接入 [N45§2.11 的完整八項合同](c5_excess_two_nonadjacent_unit_core45.md#211-單缺額查證與無-u-二連通子域)。
僅排同一無 U／L long／S short 且 actual 真框邊 pair、r split22 的原三環單 bridge 子域：
J1 指定 triangle，恰兩份有限非空 connected 原 W1/W2，W1 唯一接 J1 的原 x1 witness、
屬完整 L；W2 唯一接原 x2∈J3∪q-arm、屬完整 S。保原 G／M／β、完整 Σ933／941 或整圖 D5 像、ε=2、
完整 degree／attachments／witnesses、M 自身同 β minimal 且拒絕，以及全部原 relations／空 fibres／full lifts。
J2/J3 奇長任意≥3、p/q 原臂長任意≥0，含 p=a1、q=a3、a3=v 與所有合法接點／mi；
任意有限 Wi 大小均包含，不為容納旁支刪原附件，也不把必要容量認作來源實現。

W1 確實破壞 [1e 的雙 witness 保證](../audits/2026-10-11-br-sd-1e-337d018b/PROOF.md#3-可重用-private-witness-preservation-lemma)，
W2 可破壞 [1c 的完整 terminal 前提](../audits/2026-10-11-br-sd-1c-fd6e1112/PROOF.md#6-路線-b2保-actual-pair-support-的局部末端引理)。
本證明改由保留的 J2 原 witness 迫同一 `P_J2={T,D}`，以唯一原 S–L 接口作屏障；
q 起始的 T/D 交替追色在原 S 內形成有限 block–all-vertex incidence tree 的不回頭路徑，矛盾。
完整 lists 與 M／同 β／s=D 的全延拓等價，含 effective-H 忽略原點的允許色因子；
不使用 `D∈L(x1)⇒D∈P_J1`，不依 H_M 二連通、SD-A 或 R31 minor。
任意大小结論由獨立審查的紙面證明承擔，六個 synthetic fixtures 僅是具名有限 controls；
actual source `not triggered`，無新 Lean theorem。BR採納當輪完整父身份新增關閉數為0；
後續完整`N45-S-NOU-LS-PAIR`及其他N2 exact-S已由
[N45§2.14](c5_excess_two_nonadjacent_unit_core45.md#214-e-arc2-接入全部-spoke4554-排除與原55化約)涵蓋，原封存證據不改。
指定完整Σ契約的原55已有[九格覆蓋](c5_excess_two_n2_ll_cut.md)；契約外原55、
一般N2／E、原Σ933／941來源的ε≥3下界與`K∞=K≤5`仍OPEN。
其他兩旁支只佔 J1/J2 triangle witnesses且 J3／q 末端完整時，仍須先核既採 terminal lemma，
不能重列為新待證子域。採納與 publication custody 的實際紀錄見
[本輪紀錄](history/2026-10-11-br-sd-1g-adoption.md)；新 custody 入口為
`python3 audits/2026-10-11-br-sd-1g-adoption-publication/verify.py --check`，提交後加 `--require-tracked`。

R31 已有同末端不同二接點的 C3–C3–C3 簡單臂正常形非 disk 證書。
仍須把任意長奇環及重複色外臂化到該目標：接點末端保留共用點與兩接點，
中間保留兩共用點與 S 錨點，另一末端保留共用點與兩個 T 錨點；
建立 boundary 固定且互斥的 branch sets，再縮臂、逐步核對 degree、四列與
刪邊著色，最後合成拓撲證書回來源。精確要求見 [R31 §4](c5_degree5_same_terminal_triangles.md#4-精確停止點)。
R28 的 list 等價及 R30 的另一接點型不能取代這一步。

各報告保留指定依賴、重播命令及實際重跑／沿用的範圍。degree-5 報告對應
同名 `scripts/c5_degree5_<主題>.py` 與 `artifacts/c5_degree5_<主題>/observations.json`。
例如 R31 的 [checker](../scripts/c5_degree5_same_terminal_triangles.py) 與
[證書](../artifacts/c5_degree5_same_terminal_triangles/observations.json) 只重播正常形覆蓋；
通過不會補上任意長來源缺口。R9 對應 [K4 checker](../scripts/c5_k4_blocks.py)，
Lean 支援的精確 theorem 與 axiom audit 見 [接合基礎](lean_root_interfaces.md)。

[研究歷史](STATUS_HISTORY.md) §9–16 記錄 R9–R15，§17–22 記錄 R16–R20，
§23–27 記錄 R21–R23 與 Lean 接合基礎，§28–37 記錄 R24–R31 與發布核對。
R 編號不等於 STATUS 歷史節號。提交狀態以即時 Git 為準。

2026-10-11實際重播範圍、文件／Lean檢查及省略項目見[整理紀錄](history/2026-10-11-single-deficit-progress.md)。
一般單側／共同出口、候選 A 與 `K∞=K≤5` 仍未證。
