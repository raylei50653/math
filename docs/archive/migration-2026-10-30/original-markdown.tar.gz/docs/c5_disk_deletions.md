# 固定 C5 disk：三角化母圖與單邊刪除實驗

2026-09-16。**有限計算證據，非 Lean 定理。** 本輪使用 plantri 5.8 生成
`k=0,1,2,3` 的母圖，逐張檢查幾何，再枚舉每條非外圈邊的單次刪除。
主要問題是：相同完整 Σ 是否決定相同的單步刪邊後繼集合？

## 1. 結果與精確排除範圍

**排除「即使固定 k，母圖的 Σ 仍足以決定所有單步後繼」這個命題。**
`k=3` 有五個帶標號 Σ 群發生碰撞；§3 給出具體圖。
差異全部來自能否刪除一條邊而保持原 Σ，並非不同的嚴格放寬後繼。

**在本輪全部母圖中，排除「相同 k、相同 Σ，卻有不同嚴格單步後繼集合」的反例。**
實際比較 11,070 對相同 k、相同 Σ 的母圖，嚴格後繼碰撞為零。
這個有界排除依賴 plantri 對指定母圖類的完整生成；不是一般刪邊同餘定理。

**沒有找到既有 132-state catalogue 之外的 relation。** 本輪共出現 87 個 Σ；
逐一比對 `artifacts/c5_cells/cells.json` 的 key。此結果只覆蓋下述樣本，
不能用來排除更大 k、多邊刪除或其他 cell 的新 relation。

| k | plantri 嵌入同構類 | 固定邊界母圖數 | 母圖 Σ 數 | 單刪 Σ 數 | 單刪但非同層母圖 Σ 數 | 累積 Σ 數 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | 1 | 5 | 5 | 5 | 5 | 10 |
| 1 | 4 | 21 | 11 | 15 | 10 | 21 |
| 2 | 14 | 105 | 26 | 36 | 25 | 51 |
| 3 | 69 | 595 | 51 | 67 | 36 | 87 |

共有 726 張固定邊界母圖、7,500 個 `(T,e)` 刪邊案例，其中 3,140 次嚴格放寬、
4,360 次保持 Σ。母圖與子圖合併去重後，共核對 4,906 個固定邊界圖。
每個圖核對所有 240 個合法具名 boundary assignments，共 1,177,440 次回溯查詢。

樣本中首次出現於 k=0、1、2、3 的 Σ 數分別為 10、11、30、36。
這是**母圖或至多刪一邊樣本中的最小 k**，不是任意 cell 的最小代表大小。
各層仍有新增，因此本輪沒有觀察到樣本 relation 飽和。

## 2. 幾何類別、標號與允許操作

母圖 T 滿足：

- 有限簡單圖，恰有 k 個內點，指定外面為簡單 C5。
- 所有有界面均為三角形；允許 boundary chords、分離三角形及外圈二度點。
- 保存平面 rotation system；不是僅檢查抽象圖 planar。
- 外圈固定為 `0–1–2–3–4–0`；內點為 `5,...,4+k`。

使用 `plantri -a -P5 -c2 -m2 N`，其中 `N=5+k`。
`-P5` 固定外面長度五；`-c2 -m2` 允許 chords 及外圈二度點。
plantri 依嵌入同構去重，外面受區分。對每張輸出展開五個起點與兩個方向，
再只按**固定 boundary 的內點置換**去重。Σ key 不對 D5 取商。
參見 [官方手冊的 disk 模式](https://users.cecs.anu.edu.au/~bdm/plantri/plantri-guide.txt)。

每個母圖恰有 `3k+7` 條邊，允許刪除集合為

\[
D(T)=E(T)\setminus E(C_5),\qquad |D(T)|=3k+2.
\]

「非外圈邊」包括 boundary chord、boundary–interior 邊及 interior–interior 邊；
不只是兩端均為內點的邊。每次恰刪一條，保留全部頂點。
子圖繼承母圖的 disk drawing，但不要求其有界面仍為三角形。
本輪沒有依 Σ 剪枝，也沒有從子圖繼續刪第二條邊。

**未枚舉範圍：** k≥4、兩條以上刪邊、刪外圈邊、刪點、loops、平行邊。
沒有額外將「無 chords」子類獨立做完備性統計；本輪的碰撞 witness 有 chord。
本輪不使用或證明固定 k 的 completion lemma，也不宣稱覆蓋全部 k≤3 cells。
例如 k=0 的裸 C5 需要從母圖刪兩條 chords，本輪 k=0 樣本便不包含它。

## 3. 具體碰撞：同 Σ、不同自我後繼

定義

\[
S(T)=\{\Sigma(T-e):e\in D(T)\},\qquad
S^+(T)=S(T)\setminus\{\Sigma(T)\}.
\]

兩張母圖 A、B 均有 k=3。以下只列固定 C5 以外的邊：

```text
A = k3-t175
03 05 06 07 15 16 17 25 35 56 67

B = k3-t180
03 05 06 07 15 25 26 27 36 57 67
```

兩者的完整 Σ 相同，10-bit key 均為 199，即接受色型
`01012, 01021, 01023, 01212, 01213` 及其共同 S4 換色。
key 是既有規格下的證書索引；完整 240-bit 關係亦已逐列比較。

| 刪邊結果 | A 的可刪邊 | B 的可刪邊 |
| --- | --- | --- |
| 199（原 Σ） | 06、07、16、17、56、67 | 無 |
| 255 | 03 | 03 |
| 967 | 05、15、25、35 | 05、06、07、15、25、26、27、36、57、67 |

所以

\[
S(A)=\{199,255,967\}\ne\{255,967\}=S(B),
\qquad S^+(A)=S^+(B)=\{255,967\}.
\]

其餘碰撞群的 Σ key 為 271、314、632、721，是這個 relation 的其餘 D5 位置。
所有碰撞都只出现在 k=3，且只涉及原 Σ 後繼是否存在。

| k | 同 k、同 Σ 的母圖對數 | S 碰撞的 Σ 群數 | S⁺ 碰撞的 Σ 群數 |
| --- | ---: | ---: | ---: |
| 0 | 0 | 0 | 0 |
| 1 | 15 | 0 | 0 |
| 2 | 390 | 0 | 0 |
| 3 | 10,665 | 5 | 0 |

**這不是「合併必定漏掉 catalogue relation」的反例。**
此例只否定完整單步後繼由 Σ 唯一決定；兩張圖的嚴格後繼仍相同。
更沒有證明忽略自環即可安全合併：保持 Σ 的刪邊可能改變下一步的能力，
本輪未計算那些後續。多步安全剪枝仍需額外介面或行為等價證明。

## 4. 證書、信任鏈與重現

- [檢查器](../scripts/c5_disk_deletions.py)：直接枚舉每個色型的 `4^k` 個內部賦色；
  與既有 `direct_graph_extend` 的頂點回溯比較所有 240 個 boundary assignments。
- [完整結果](../artifacts/c5_disk_deletions/observations.json)：所有母圖、來源標號、逐邊結果、
  完整 relation、碰撞分組、Σ realization 次數與樣本首次出現層。
- [生成紀錄](../artifacts/c5_disk_deletions/plantri/manifest.json)：plantri 版本、下載 URL、
  archive/source SHA256、編譯命令、四次生成命令與原始輸出 SHA256。
  同目錄的 `k0.ascii` 至 `k3.ascii` 保存原始 rotation systems。

`parent_realizations` 計數固定 boundary、內點同構去重後的母圖；
`one_deletion_realizations` 計數 `(T,e)`，不同 e 即使產生同構子圖仍分別計數。
這些不是所有任意大小 realization 的數量。

幾何檢查逐 dart 走面，核對 simple/symmetric adjacency、連通性、Euler 等式、
唯一 C5 外面、其餘面均為三角形及邊數，並另用 NetworkX 驗證抽象平面性。
子圖的合法 disk drawing 由在已驗母圖上刪邊取得。
此檢查保證輸入圖的幾何合法性，**不獨立證明 plantri 沒漏圖**。
Σ 計算與固定標號去重也是 Python 計算證據，沒有新增 Lean 證書。

```bash
uv run --with networkx==3.5 python scripts/c5_disk_deletions.py --check
lake build
git diff --check
```

`--check` 不需要安裝 plantri；會從保存的原始輸出重建全部結果並逐 byte 比較。
本輪 `--check`、`lake build`（8,819 jobs，僅既有 lint）、文件連結與 whitespace
檢查均通過；四份 plantri 原始輸出重新生成亦逐 byte 一致。
重跑生成器時，使用 manifest 指定的官方 archive，核對雜湊，依其 compile 與
argv 執行，再比對四份 ASCII 輸出；不把外部生成器的成功退出當成 Lean 完備性證明。

下一個有界問題是：對上述 A、B，比較從全部保持 Σ 的刪邊後繼出發的嚴格出口，
判斷自環差異是否會變成真正的多步 catalogue 差異。本輪停在單邊實驗，未啟動該搜尋。

後續：[A/B same-Σ closure 實驗](c5_disk_weak_successors.md) 已獨立完成這一對的
全部刪邊格；weak exits、全部 observable traces 與有限 weak bisimulation 均相同。
此後續結論僅限 A/B 的後代，不擴張本報告對全體母圖的一步排除範圍。
