# 部分消元歷史也能精確表示全部解

2026-10-27。接續[完整解空間](four_color_mathematical_model.md)與
[完整消元紙證](four_color_completeness.md)。本輪完成獨立原型及有限範圍核對；
所屬研究線現況見[四色導覽](four_color_guide.md)。主求解器的模式與輸出不變。

## 結論與精確契約

不必先消完所有點，也不必把每步回填色展開為完整表格。只要保留**剩餘約束**與
**已消點的精確回填規則**，即可隱式表示全部原解。表示全部解不等於已解出剩餘問題。

對有限簡單無向原圖及固定色，令初始因子問題為 `P_0`，色集合固定為 `{0,1,2,3}`。
完成前 `k` 步精確消元後，活動點為 `U_k`，剩餘因子問題為 `P_k`；第 `i` 步消去
`x_i`，有序接口為 `Y_i`，當時 bucket 的全部支援色為 `W_i(y)`。則

\[
\boxed{c\in\operatorname{Sol}(P_0)\iff
c|_{U_k}\in\operatorname{Sol}(P_k)
\ \land\ \bigwedge_{i=1}^{k}[c(x_i)\in W_i(c|_{Y_i})].}
\]

**紙面推導。** 單步將全部含 `x_i` 的因子合取成 `B_i(a,y)`，其餘因子為 `Q_i`。
定義 `W_i(y)={a:B_i(a,y)}`、`R_i(y)⇔W_i(y)≠∅`。原指派滿足 `Q_i∧B_i`，恰好
當其剩餘限制滿足 `Q_i∧R_i`，且原來的 `x_i` 色屬於同一接口列的 `W_i`。
逐步代入即得公式。`k=0` 是原因子本身；`k=n` 時剩餘問題仍須保留零元假因子。
若另加傳播，每一步還須逐份保持當前完整解集合；本原型沒有額外傳播。

初始每點有一元域因子，含孤點與固定色；每條原邊有異色因子。所有接口均保留
原頂點身份及同一字面色號。此處 `W_i` 是歷史 bucket 支援，單獨非空不保證全圖
可延伸；接口點的一元域及其他外側限制可能仍在 `P_k`，必須共同滿足。

## 原型的三種表示

實作為 [four_color_partial_history.py](../scripts/four_color_partial_history.py)：

| 模式 | 已消點的紀錄 | 精確性依據 |
| --- | --- | --- |
| `table` | 保存每個合法完整接口列及全部支援色 | 直接查完整 fibre |
| `recipe` | 省略歷史 fibre 表，引用當時的完整 bucket 因子 | 對同一接口列重算四個色的全部支援 |
| `mixed` | 偶數索引步存表、奇數索引步存重算規則 | 兩種精確表示逐步合成 |

因子登記表保留活動因子及回填規則引用的舊因子，包括歷史域與先前的投影表。
不能只存 `source_edges` 而忽略中間關係。各模式仍會計算完整投影表，沒有消除寬接口
的指數瓶頸；省下的是部分歷史表的持久儲存，不是省掉全部消元計算或所有關係表。

`stop_after=k` 真正只執行前 `k` 步，不先完成整圖再截短歷史。`max_checks` 限制建構時
檢查的完整 bucket 指派數；中途超限不提交該步，保留上一份精確的前綴與剩餘問題。
未完成查詢不視為空 fibre。`stop_reason` 與 `decision` 分開：停止於工作上限仍可有
精確表示，但通常保持 `undetermined`。這不改變主求解器既有 `limit` 輸出的契約。

`compile_representation` 將這份自足表示編譯成完整配色的成員判定，不讀原圖 oracle。
它核對結構、引用及座標，不是任意外來 JSON 的投影推導證書驗證器。
`reconstruct_one` 先對剩餘點找到一份共同解，再倒序依同一完整接口回填已消點；
建構表示時不提前寫色。此原型對剩餘點使用窮舉到首解，該搜尋與回填不受建構的
`max_checks` 限制，可能昂貴；不聲稱一般免搜尋或加速。

## 本輪有限核對

[獨立審核程式](../scripts/four_color_partial_history_audit.py)對每個輸入、每個截點及
三種模式，將 JSON 重載後的表示逐份對照原邊／固定色判定。枚舉包含違反固定色的
配色，以便發現錯誤接受；不只比較解數或 SAT 標籤。

| 輸入範圍 | 條件數 | 表示數 | 完整配色逐份核對次數 |
| --- | ---: | ---: | ---: |
| 0–4 點全部帶標號簡單圖 | 76 | 1,083 | 252,219 |
| 1–3 點全部圖、全部非空部分固定色 | 1,044 | 12,360 | 768,864 |
| 8 份具名控制，各用正反兩種消元順序 | 8 | 276 | 365,568 |
| seed-20261027 的 5／6 點樣本 | 16 | 312 | 835,584 |
| 合計 | 1,144 | 14,031 | 2,222,235 |

全部逐份相等。輸入中 915 份可解、229 份無解；共有 7,122 份表示同時保有已消點
與剩餘活動點。有解表示完成 11,217 次共同見證回填並逐原邊驗證。
具名控制包含 K₅、奇輪、固定色阻塞星形、外側固定條件及不連續頂點 ID。

另以 12 種工作預算、三模式核對 36 份狀態及 9,216 份配色；27 份在建構途中超限，
仍與原圖逐份相等，全部 36 份皆能另行求出一份合法解。兩組合計 14,067 份表示、
2,231,451 次成員判定與 11,253 次合法回填。

三個負控制均檢出錯誤：遺失回填限制會接受同色邊；遺失剩餘邊會接受不合法配色；
每列只留一個支援會丟掉其他原解。11 項針對測試另涵蓋所有星形接口列、原子中斷、
空圖與零元假因子、缺失歷史及字面頂點順序。

## 儲存取捨

下表量的是**整份原型表示的緊湊 JSON bytes**，包含剩餘約束、規則、歷史引用及統計；
不是程序 RSS、建構峰值或主求解器記憶體。

| 例子 | `table` | `recipe` | `mixed` |
| --- | ---: | ---: | ---: |
| 單邊，只消一個葉點 | 608 | 583 | 608 |
| 四葉星形，只消中心 | 11,519 | 3,209 | 11,519 |
| K₄，全部消元 | 3,542 | 1,857 | 3,810 |

星形的 `recipe` 不儲存 232 列歷史 fibre，但仍保存 232 列剩餘投影關係。
K₄ 的混合表示比全表更大，因為仍須保留被重算規則引用的舊表，不能把省略色表
直接當成整體記憶體必定下降。重算亦有時間成本；本輪沒有做速度比較。

## 證據與重播

- [完整審核摘要](../artifacts/four_color_partial_history/summary.json)：輸入範圍、來源 hash、逐份核對摘要、負控制及儲存數字。
- [重播與檢查收據](../artifacts/four_color_partial_history/verification.json)。
- [測試](../tools/tests/test_four_color_partial_history.py)。

```bash
python3 scripts/four_color_partial_history_audit.py --out /tmp/partial-history.json
PYTHONHASHSEED=17 python3 scripts/four_color_partial_history_audit.py --out /tmp/partial-history-seed17.json
cmp /tmp/partial-history.json /tmp/partial-history-seed17.json
python3 -m unittest discover -s tools/tests -p 'test_four_color_partial_history.py' -v
python3 scripts/check_docs.py
python3 tools/docgraph --include 'docs/**/*.md' check
git diff --check
```

輸出路徑必須尚不存在，避免覆寫證據。正常與 seed-17 審核結果逐位元組相同。
本輪完成的是上述部分歷史表示契約的紙面推導與有限 Python 核對；未新增 Lean
形式化，未接入主求解器，沒有一般儲存／時間優勢或平面必可染結論。
